<?php

namespace V3\App\Models\Portal\Academics;

use V3\App\Models\BaseModel;

class School extends BaseModel
{
    protected string $table = 'school_data';

    public function __construct(\PDO $pdo)
    {
        parent::__construct($pdo);
        parent::table($this->table);
    }
}
