<?php

namespace V3\App\Controllers\Explore;

use V3\App\Common\Routing\Group;
use V3\App\Common\Routing\Route;
use V3\App\Common\Utilities\HttpStatus;
use V3\App\Services\Explore\UserService;

#[Group('/public/users')]
class UserController extends ExploreBaseController
{
    private UserService $userService;

    public function __construct()
    {
        parent::__construct();
        $this->userService = new UserService($this->pdo);
    }

    #[Route('', 'POST', ['api', 'auth', 'role:admin'])]
    public function storeUser(): void
    {
        $data = $this->validate($this->getRequestData(), [
            'creator_id' => 'required|integer|min:1',
            'created_by' => 'required|string|filled|max:255',
            'first_name' => 'required|string|filled|max:255',
            'last_name' => 'nullable|string|max:255',
            'username' => 'required|string|filled|max:255',
            'email' => 'nullable|email|max:255',
            'password' => 'required|string|filled|min:6',
            'role' => 'required|string|in:Admin,User',
            'picture_ref' => 'nullable|string|max:255',
        ]);

        $userId = $this->userService->createUser($data);

        if ($userId) {
            $this->respond(
                [
                    'success' => true,
                    'message' => 'User created successfully',
                    'user_id' => $userId,
                ],
                HttpStatus::CREATED
            );
        }

        $this->respondError(
            'Failed to create user',
            HttpStatus::BAD_REQUEST
        );
    }

    #[Route('/login', 'POST', ['api'])]
    public function login(): void
    {
        $data = $this->validate($this->getRequestData(), [
            'username' => 'required|string|filled|max:255',
            'password' => 'required|string|filled|min:6',
        ]);

        $user = $this->userService->login(
            $data['username'],
            $data['password']
        );

        if (!empty($user)) {
            $this->respond(
                [
                    'success' => true,
                    'message' => 'Login successful',
                    'data' => $user,
                ],
                HttpStatus::OK
            );
        }

        $this->respondError(
            'Invalid username or password',
            HttpStatus::UNAUTHORIZED
        );
    }

    #[Route('/{id:\d+}', 'PUT', ['api', 'auth', 'role:admin'])]
    public function updateUser(array $vars): void
    {
        $data = $this->validate([...$this->getRequestData(), ...$vars], [
            'id' => 'required|integer|min:1',
            'first_name' => 'required|string|filled|max:255',
            'last_name' => 'nullable|string|filled|max:255',
            'username' => 'nullable|string|filled|max:255',
            'email' => 'nullable|email|max:255',
            'password' => 'nullable|string|min:6',
            'role' => 'required|string|in:Admin,User',
            'picture_ref' => 'nullable|string|max:255',
            'status' => 'required|string|in:1,0',
        ]);

        $updated = $this->userService->updateUser($data);

        if ($updated) {
            $this->respond(
                [
                    'success' => true,
                    'message' => 'User updated successfully',
                ],
                HttpStatus::OK
            );
        }

        $this->respondError(
            'Failed to update user',
            HttpStatus::BAD_REQUEST
        );
    }

    #[Route('', 'GET', ['api', 'auth', 'role:admin'])]
    public function getUsers(): void
    {
        $this->respond(
            [
                'success' => true,
                'data' => $this->userService->getUsers(),
            ],
            HttpStatus::OK
        );
    }

    #[Route('/{id:\d+}', 'DELETE', ['api', 'auth', 'role:admin'])]
    public function deleteUser(array $vars): void
    {
        $data = $this->validate($vars, [
            'id' => 'required|integer|min:1',
        ]);

        $deleted = $this->userService->deleteUser($data['id']);

        if ($deleted) {
            $this->respond(
                [
                    'success' => true,
                    'message' => 'User deleted successfully',
                ],
                HttpStatus::OK
            );
        }

        $this->respondError(
            'Failed to delete user',
            HttpStatus::BAD_REQUEST
        );
    }
}
