<?php

namespace V3\App\Services\Explore;

use PDO;
use Throwable;

class AuthBootstrapService
{
    private CbtUserService $cbtUserService;
    private ProgramProfileService $profileService;
    private PDO $pdo;

    public function __construct(PDO $pdo)
    {
        $this->pdo = $pdo;
        $this->cbtUserService = new CbtUserService($pdo);
        $this->profileService = new ProgramProfileService($pdo);
    }

    /**
     * Bootstrap identity + profile
     *
     * - Creates user if not exists
     * - Creates default profile if none exists
     * - Updates phone (user) if provided
     * - Updates birth_day (profile) if provided
     */
    public function bootstrap(array $googleData, ?string $phone = null, ?string $birthDate = null): array
    {
        $this->pdo->beginTransaction();

        try {
            // 1. Identity
            $user = $this->cbtUserService->findOrCreateUserByEmail($googleData);

            // 2. Update phone on identity if missing
            if ($phone && empty($user['phone'])) {
                $this->cbtUserService->updateUser($user['id'], [
                    'phone' => $phone
                ]);
            }

            // 3. Profiles
            $profiles = $this->profileService->getProfilesByUserId($user['id']);

            // 4. Create default profile if none exists
            if (empty($profiles)) {
                $this->profileService->createProfile([
                    'user_id' => $user['id'],
                    'first_name' => $googleData['first_name'],
                    'last_name' => $googleData['last_name'],
                    'birth_date' => $birthDate,
                ]);

                $profiles = $this->profileService->getProfilesByUserId($user['id']);
            }

            // 5. Update birth day on default profile if provided
            if ($birthDate && !empty($profiles)) {
                $this->profileService->updateProfile([
                    'id' => $profiles[0]['id'],
                    'birth_date' => $birthDate,
                    'gender' => $googleData['gender'],
                    'user_id' => $user['id'],
                ]);
            }

            $this->pdo->commit();

            return [
                'user' => $this->cbtUserService->getUserByEmail($user['email']),
                'profiles' => $profiles
            ];
        } catch (Throwable $e) {
            $this->pdo->rollBack();
            throw $e;
        }
    }

    public function bootstrapWithGoogleToken(string $token): array
    {
        $googleProfile = $this->fetchGoogleUserProfile($token);
        [$firstName, $lastName] = $this->resolveNames($googleProfile);

        return $this->bootstrap([
            'first_name' => $firstName,
            'last_name' => $lastName,
            'email' => $googleProfile['email'],
            'profile_picture' => $googleProfile['picture'] ?? null,
            'gender' => $googleProfile['gender'] ?? null,
        ]);
    }

    private function resolveNames(array $googleProfile): array
    {
        $firstName = $googleProfile['given_name'] ?? null;
        $lastName = $googleProfile['family_name'] ?? null;

        if ((!$firstName || !$lastName) && !empty($googleProfile['name'])) {
            $nameParts = preg_split('/\\s+/', trim($googleProfile['name']), -1, PREG_SPLIT_NO_EMPTY);

            if (!$firstName && !empty($nameParts)) {
                $firstName = array_shift($nameParts);
            }

            if (!$lastName && !empty($nameParts)) {
                $lastName = array_pop($nameParts);
            }
        }

        $firstName = $firstName ?: 'User';
        $lastName = $lastName ?: 'User';

        return [$firstName, $lastName];
    }

    private function fetchGoogleUserProfile(string $token): array
    {
        $curl = curl_init();

        curl_setopt_array($curl, [
            CURLOPT_URL => 'https://www.googleapis.com/oauth2/v3/userinfo',
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 15,
            CURLOPT_HTTPHEADER => [
                "Authorization: Bearer {$token}",
                'Accept: application/json',
            ],
        ]);

        $response = curl_exec($curl);
        $httpStatus = curl_getinfo($curl, CURLINFO_HTTP_CODE);
        $error = curl_error($curl);
        curl_close($curl);

        if ($error) {
            throw new \RuntimeException("Failed to fetch Google profile: {$error}");
        }

        $result = json_decode($response, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new \RuntimeException('Failed to parse Google profile response.');
        }

        if ($httpStatus >= 400 || isset($result['error'])) {
            $message = $result['error_description'] ?? $result['error'] ?? 'unknown error';
            throw new \RuntimeException("Google profile request failed: {$message}");
        }

        if (empty($result['email'])) {
            throw new \RuntimeException('Google profile is missing an email address.');
        }

        return $result;
    }

    public function signupWithEmail(array $data): array
    {
        $this->pdo->beginTransaction();

        try {
            $user = $this->cbtUserService->findOrCreateUserByEmail($data);

            $this->profileService->createProfile([
                'user_id' => $user['id'],
                'first_name' => $data['first_name'],
                'last_name' => $data['last_name'],
                'birth_date' => $data['birth_date'],
                'gender' => $data['gender'],
            ]);

            $this->pdo->commit();

            return [
                'user' => $user,
                'profiles' => $this->profileService->getProfilesByUserId($user['id'])
            ];
        } catch (Throwable $e) {
            $this->pdo->rollBack();
            throw $e;
        }
    }
}
