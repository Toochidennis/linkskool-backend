<?php

namespace V3\App\Common\Utilities;

use PDOException;

class Logger
{
    private static string $logFile = __DIR__ . '/../../../public/logs/error.log';

    public static function init(): void
    {
        set_exception_handler(function (\Throwable $e) {
            self::write($e);

            $isSQL  = $e instanceof PDOException;
            $isSafe = self::isSafeException($e);

            http_response_code($isSQL ? 500 : ($isSafe ? 400 : 500));
            header('Content-Type: application/json');

            echo json_encode([
                'success' => false,
                'message' => ($isSafe && !$isSQL)
                    ? $e->getMessage()
                    : 'Something went wrong. Please try again later.'
            ]);

            exit;
        });
        // Non-fatal PHP errors (warnings, notices, etc.)
        set_error_handler(function ($errno, $errstr, $errfile, $errline) {
            $message = self::buildMessage(
                "ERROR [$errno]",
                $errstr,
                $errfile,
                $errline
            );
            file_put_contents(self::$logFile, $message, FILE_APPEND);
            return true; // suppress default PHP output
        });

        // Fatal error catcher (shutdown)
        register_shutdown_function(function () {
            $error = error_get_last();
            if ($error !== null) {
                $message = self::buildMessage(
                    "FATAL ERROR",
                    $error['message'],
                    $error['file'],
                    $error['line']
                );
                file_put_contents(self::$logFile, $message, FILE_APPEND);

                http_response_code(500);
                header('Content-Type: application/json');
                echo json_encode([
                    'success' => false,
                    'message' => 'Something went wrong. Please try again later.'
                ]);
            }
        });
    }

    /** Write full exception details to log file */
    public static function write(\Throwable $e): void
    {
        $type = $e instanceof PDOException ? 'SQL EXCEPTION' : 'EXCEPTION';
        $message = self::buildMessage(
            $type,
            $e->getMessage(),
            $e->getFile(),
            $e->getLine()
        );
        file_put_contents(self::$logFile, $message, FILE_APPEND);
    }

    public static function info(string $message, array $context = []): void
    {
        $payload = $message;

        if (!empty($context)) {
            $json = json_encode($context, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
            $payload .= ' | context=' . ($json === false ? 'json_encode_failed' : $json);
        }

        file_put_contents(
            self::$logFile,
            self::buildMessage('INFO', $payload, __FILE__, __LINE__),
            FILE_APPEND
        );
    }

    /** Simple classification for user-caused errors (extend if needed) */
    private static function isUserError(\Throwable $e): bool
    {
        $msg = strtolower($e->getMessage());
        return str_contains($msg, 'required') ||
            str_contains($msg, 'invalid')  ||
            str_contains($msg, 'missing')  ||
            str_contains($msg, 'not found');
    }

    private static function buildMessage(
        string $type,
        string $message,
        string $file,
        int $line
    ): string {
        $timestamp = date('Y-m-d H:i:s');
        $ip     = $_SERVER['REMOTE_ADDR']   ?? 'CLI';
        $method = $_SERVER['REQUEST_METHOD'] ?? 'N/A';
        $uri    = $_SERVER['REQUEST_URI']    ?? 'N/A';
        $query  = $_SERVER['QUERY_STRING']   ?? '';

        return "[$timestamp] $type: $message in $file on line $line\n" .
            "Request: $method $uri?$query from $ip\n\n";
    }

    private static function isSafeException(\Throwable $e): bool
    {
        return $e instanceof \RuntimeException
            || $e instanceof \InvalidArgumentException
            || $e instanceof \DomainException
            || $e instanceof \LogicException;
    }
}
